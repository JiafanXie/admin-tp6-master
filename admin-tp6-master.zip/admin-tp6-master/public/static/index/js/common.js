let layer = layui.layer,
	laydate = layui.laydate,
	form = layui.form,
	upload = layui.upload;

function ajax(type, url, data, callback) {
	$.ajax({
		type: type,
		url: url,
		data: data,
		success: function (res) {
			if (res.code == -2) {
				layer.msg(res.msg);
				setTimeout(function () {
					location.href = '/index/login/login';
				}, 500)
			}
			callback(res);
		}
	})
}

/**
 * 弹出信息并终止程序
 * @param msg
 * @returns {boolean}
 */
function showMsg(msg) {
	layer.msg(msg);
	throw new Error(msg);
}

/**
 * 获取参数
 * @param param
 * @returns {*}
 */
function getParam(param) {
	let str = window.location.search.substr(1);
	let param_arr = str.split('&');
	let obj = {};
	for (let i = 0; i <= param_arr.length - 1; i++) {
		let k = param_arr[i].split('=')[0];
		let v = param_arr[i].split('=')[1];
		obj[k] = v;
	}
	return obj[param];
}