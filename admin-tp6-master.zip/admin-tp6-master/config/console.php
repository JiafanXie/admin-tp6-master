<?php
// +----------------------------------------------------------------------
// | 控制台配置
// +----------------------------------------------------------------------
return [
	// 指令定义
	'commands' => [
		'movieCity'    => 'app\command\movieCity',
		'movieAddress' => 'app\command\movieAddress',
		'movieCinema'  => 'app\command\movieCinema',
		'moviePlan'    => 'app\command\moviePlan',
		'movie'        => 'app\command\movie',
	]
];
