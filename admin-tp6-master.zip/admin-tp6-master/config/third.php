<?php

return [
	'wx' => [
		'applets_app_id'            => 'wx4b3865630b7d076a',
		'applets_app_secret'        => 'c6f62636b15811df81bdb8f3f47e086d',
		'account_app_id'            => 'wx050f81d8ab8a940d',
		'account_app_secret'        => '6b5af021085f16baeec6822caf2d0c7a',
		'pay_app_key'               => 'SDZN2198VKNSFA8745FAsg486461SADd',
		'mch_id'                    => '1603428532',
		'notify_url'                => request()->domain() . '/api/notify/notify',
		'ticket_account_app_id'     => 'wx542aa98fe826783f',
		'ticket_account_app_secret' => 'ef9651b27ed25cf703ad57ef09cfb7b2 '
	]
];