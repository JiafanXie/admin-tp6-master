<?php

return [
	'key'               => 'PDx6tprydHRNTgnq5EBhwWasGJ1k4Uz9',
	'iat'               => time(),   // 签发时间
	'nbf'               => time(),   // 生效时间
	'access_token_exp'  => time() + 300000000, // 过期时间
	'refresh_token_exp' => time() + 24 * 3600 * 30, // 过期时间
];
