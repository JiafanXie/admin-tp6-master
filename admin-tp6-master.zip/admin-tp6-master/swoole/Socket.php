<?php
declare(strict_types=1);

namespace swoole;

use app\service\MovieOrderService;
use core\third\movie\MovieApi;
use redis\Redis;
use think\Db;
use think\Exception;

/**
 * socket
 * Class Socket
 * @package swoole
 */
class Socket
{
	static $server;

	public function __construct(string $host, int $port)
	{
		self::$server = new \Swoole\WebSocket\Server($host, $port);
		self::$server->set([
			'worker_num' => 8,
			'daemonize'  => false,
		]);
		self::$server->on('open', [$this, 'onOpen']);
		self::$server->on('message', [$this, 'onMessage']);
		self::$server->on('request', [$this, 'onRequest']);
		self::$server->on('close', [$this, 'onClose']);
		self::$server->start();
	}

	/**
	 * 监听websocket的打开连接事件
	 * @param $server
	 * @param $request
	 */
	public function onOpen($server, $request)
	{
		$server->push($request->fd, json_encode(['code' => 200, 'msg' => '连接成功']));
	}

	/**
	 * 监听websocket的消息事件
	 * @param $server
	 * @param $frame
	 */
	public function onMessage($server, $frame)
	{
		$data = json_decode($frame->data);
		if (isset($data->type)) {
			if ($data->type == 'PING') $this->heartCheck($server, $frame);
			if ($data->type == 'bind_ticket_dealer_id') $this->bind($server, $frame, $data);
		}
	}

	/**
	 * 监听websocket的关闭连接事件
	 * @param $server
	 * @param $fd
	 */
	public function onClose($server, $fd)
	{
		Redis::getInstance()->hDel('fd', 'fd_' . $fd);
		Redis::getInstance()->hDel('ticket', 'id_' . self::$server->getClientInfo($fd)['uid'] ?? '');
		echo "client {$fd} closed\n";
	}

	/**
	 * 心跳回应
	 * @param $server
	 * @param $frame
	 * @return bool
	 */
	public function heartCheck($server, $frame)
	{
		$server->push($frame->fd, json_encode(['code' => 200, 'msg' => 'PONG']));
		return true;
	}

	/**
	 * 绑定票商id
	 * @param $server
	 * @param $frame
	 * @param $data
	 * @return bool
	 */
	public function bind($server, $frame, $data)
	{
		if (empty($data->ticket_dealer_id)) {
			$server->push($frame->fd, json_encode(['code' => 422, 'msg' => '票商id不能为空']));
			return false;
		}
		Redis::getInstance()->hSet('fd', 'fd_' . $frame->fd, $frame->fd);
		Redis::getInstance()->hSet('ticket', 'id_' . $data->ticket_dealer_id, $frame->fd);
		$server->bind($frame->fd, $data->ticket_dealer_id);
		$server->push($frame->fd, json_encode(['code' => 200, 'msg' => '绑定成功']));
		return true;
	}

	/**
	 * 触发http方法
	 * @param \Swoole\Http\Request $request
	 * @param \Swoole\Http\Response $response
	 * @throws Exception
	 */
	public function onRequest(\Swoole\Http\Request $request, \Swoole\Http\Response $response)
	{
		$post = $request->post;
		// 五分钟竞价定时器
		if ($post['type'] == 'bid') $this->bid($post['order_info']);
		// 订单广播给所有票商
		if ($post['type'] == 'broadcast') $this->broadcast($post['fd']);
		// 票商竞价成功通知
		if ($post['type'] == 'bid_success') $this->bidSuccess($post['fd'], $post['order_num']);
		// 订单15分钟未支付自动作废
		if ($post['type'] == 'del_order') $this->delOrder($post['order_num']);
		// 电影结束两小时后结算各个角色佣金
		if ($post['type'] == 'settled') $this->settled($post['order_info']);
	}

	/**
	 * 广播
	 * @param $fd
	 * @throws Exception
	 */
	public function broadcast($fd)
	{
		if (empty($fd)) throw new Exception();
		foreach ($fd as $v) {
			self::$server->push((int)$v, '您有一个新订单等待报价');
		}
	}


	/**
	 * 竞价成功
	 * @param $fd
	 * @param $order_num
	 * @throws Exception
	 */
	public function bidSuccess($fd, $order_num)
	{
		if (empty($fd)) throw new Exception();
		$ticket_dealer_id = self::$server->getClientInfo($fd);
		NoticeService::getInstance()->sendTicketDealer($order_num, $ticket_dealer_id);
		self::$server->push((int)$fd, '恭喜您竞价成功');
	}

	/**
	 * 竞价定时器
	 * @param $order_info
	 */
	public function bid($order_info)
	{
		swoole_timer_after(300000, function () use ($order_info) {
			$order_info = json_decode($order_info);
			$bid_info = BidService::getInstance()->getAllData([
				'where' => ['order_id' => $order_info->id],
				'field' => ['ticket_dealer_id', 'price', 'id'],
			]);
			$sum_price = $bid_info[0]['price'];
			$bid_id = $bid_info[0]['id'];
			$ticket_dealer_id = $bid_info[0]['ticket_dealer_id'];
			foreach ($bid_info as $v) {
				if ($v['price'] < $sum_price) {
					$sum_price = $v->price;
					$ticket_dealer_id = $v->ticket_dealer_id;
					$bid_id = $v->id;
				}
				if ($v->bid == 1) return false;
			}
			// 更新中标状态
			BidService::getInstance()->updateData([
				'where' => ['id' => $bid_id],
				'data'  => ['bid' => BidService::getInstance()->getBid(), 'ticket_order_status' => BidService::getInstance()->getUndoneStatus()],
			]);
			if ($order_info->order_type == OrderService::getInstance()->getFixedOrderType()) {
				$proxy_info = ProxyService::getInstance()->getData([
					'where' => ['id' => $order_info->proxy_id]
				]);
				$proxy_credit = ($order_info->sum_price - $sum_price) * $proxy_info->rake / 100;
				OrderService::getInstance()->updateData([
					'where' => ['id' => $order_info->id],
					'data'  => [
						'settlement_price' => $sum_price,
						'proxy_credit'     => $proxy_credit
					]
				]);
			} else {
				OrderService::getInstance()->updateData([
					'where' => ['id' => $order_info->id],
					'data'  => ['settlement_price' => $sum_price + system_config('system.ticket_inc')]
				]);
			}
			// 竞价成功信息推送给票商
			curl_request('http://127.0.0.1:9501', 'POST', [
				'type'      => 'bid_success',
				'fd'        => Redis::getInstance()->hGet('ticket', 'id_' . $ticket_dealer_id),
				'order_num' => $order_info->order_num
			]);
		});
	}

	/**
	 * 订单15分钟未支付作废处理
	 * @param $order_num
	 */
	public function delOrder($order_num)
	{
		swoole_timer_after(900000, function () use ($order_num) {
			MovieOrderService::getInstance()->del(['order_num' => $order_num]);
			MovieApi::getInstance()->unlockSeat($order_num);
		});
	}

	/**
	 * 结算
	 * @param $order_info
	 */
	public function settled($order_info)
	{
		$order_info = json_decode($order_info);
		$time = strtotime($order_info->start_time) + $order_info->movie_duration * 60 + 7200 - time();
		swoole_timer_after($time, function () use ($order_info) {
			// 代理商结算
			$proxy_info = ProxyService::getInstance()->getData([
				'where' => ['id' => $order_info->proxy_id]
			]);
			Db::transaction(function () use ($order_info, $proxy_info) {
				if ($proxy_info->pay_info->isEmpty() == false) {
					ProxyService::getInstance()->updateFreezeBalance($order_info->proxy_id, $order_info->proxy_credit, 2);
					ProxyService::getInstance()->updateBalance($order_info->proxy_id, $order_info->proxy_credit, 1);
					$before_balance = 0;
					$after_balance = 0;
				} else {
					$before_balance = $proxy_info->balance;
					$after_balance = $proxy_info->balance + $order_info->proxy_credit;
				}
				ProxyFinanceService::getInstance()->saveData([
					'data' => [
						'proxy_id'       => $order_info->proxy_id,
						'source_user_id' => $order_info->user_id,
						'type'           => ProxyFinanceService::getInstance()->getIncType(),
						'before_balance' => $before_balance,
						'change_balance' => $order_info->proxy_credit,
						'after_balance'  => $after_balance,
						'remark'         => '佣金结算'
					]
				]);
			});
			// 用户结算
			$user_money = $proxy_money * $proxy_info->distribution / 100;
			UserService::getInstance()->rebate($user_money, $order_info->user_id);
			if ($order_info->order_type != OrderService::getInstance()->getAutoOrderType()) {
				// 票商结算
				$ticket_dealer_money = $order_info->settlement;
				$ticket_dealer_id = BidService::getInstance()->getData([
					'where' => ['order_id' => $order_info->id, 'bid' => BidService::getInstance()->getBidStatus()]
				])->ticket_dealer_id;
				$ticket_dealer_info = TicketDealerService::getInstance()->getData([
					'where' => ['id' => $ticket_dealer_id]
				]);
				TicketDealerService::getInstance()->updateFreezeBalance($ticket_dealer_info->ticket_dealer_id, $ticket_dealer_money, 2);
				TicketDealerService::getInstance()->updateBalance($ticket_dealer_info->ticket_dealer_id, $ticket_dealer_money, 1);
				TicketDealerFinanceService::getInstance()->saveData([
					'data' => [
						'ticket_dealer_id' => $ticket_dealer_info->ticket_dealer_id,
						'source_user_id'   => $order_info->user_id,
						'type'             => TicketDealerFinanceService::getInstance()->getIncType(),
						'before_balance'   => $ticket_dealer_info->balance,
						'change_balance'   => $ticket_dealer_money,
						'after_balance'    => $ticket_dealer_info->balance + $ticket_dealer_money,
						'remark'           => '票价结算',
					]
				]);
			}
		});
	}
}