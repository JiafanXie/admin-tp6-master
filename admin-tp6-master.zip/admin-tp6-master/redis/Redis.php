<?php
declare(strict_types=1);

namespace redis;
/**
 * 链接Redis
 * Class Redis
 * @package swoole\redis
 */
class Redis
{
	/**
	 * 静态实例
	 * @var \Redis
	 */
	private static $redis = null;

	private static $config = [
		'host' => '127.0.0.1',
		'port' => 6379
	];

	private function __construct()
	{
	}

	//获取静态实例
	public static function getInstance()
	{
		if (!self::$redis instanceof \Redis) {
			self::$redis = new \Redis();
			self::$redis->connect(self::$config['host'], self::$config['port']);
		}
		return self::$redis;
	}

	/*
	 * 禁止clone
	 */
	private function __clone()
	{
	}
}