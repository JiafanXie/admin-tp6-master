<?php
declare (strict_types=1);

namespace app\admin\controller;

use app\common\controller\AdminBase;
use core\error\ErrorMsg;

use core\json\JsonResponse;
use app\common\model\Role as RoleModel;
use app\Request;
use app\service\MenuService;
use app\service\RoleService;
use think\db\exception\DbException;
use think\Exception;

class Role extends AdminBase
{
	public function index(Request $request)
	{
		$p_id  = $request->param('p_id', 0);
		$lists = RoleModel::paginate($this->pageSize);
		return view('index', [
			'lists' => $lists,
			'p_id'  => $p_id
		]);
	}

	public function form(Request $request)
	{
		$id   = $request->param('id');
		$info = [];
		$auth = [];
		if (!empty($id)) {
			$info = RoleService::getInstance()->findSingle(['id' => $id]);
			$auth = explode(',', $info['role']);
		}
		$menu_lists = MenuService::getInstance()->findAll()->toArray();
		return view('form', [
			'info'       => $info,
			'auth'       => $auth,
			'menu_lists' => array2tree($menu_lists),
		]);
	}

	public function save(Request $request)
	{
		$param = $request->param();
		$param['role'] = implode(',', $param['role']);
		try {
			RoleService::getInstance()->saveData($param);
			return JsonResponse::success('操作成功');
		} catch (\Exception $e) {
			return ErrorMsg::errorMsg($e);
		}
	}

	public function del(Request $request)
	{
		$id = $request->param('id');
		if (empty($id)) return JsonResponse::error('非法请求');
		try {
			RoleService::getInstance()->del(['id' => $id]);
			return JsonResponse::success('操作成功');
		} catch (\Exception $e) {
			return ErrorMsg::errorMsg($e);
		}
	}
}
