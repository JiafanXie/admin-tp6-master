<?php
declare(strict_types=1);

namespace app\admin\controller;

use app\common\controller\AdminBase;
use core\error\ErrorMsg;
use core\json\JsonResponse;
use app\Request;
use app\service\AdminService;
use app\service\MemberService;
use app\service\RoleService;

/**
 * 客户控制器
 * Class Member
 * @package app\admin\controller
 */
class Member extends AdminBase
{
	public function index(Request $request)
	{
		$param = $request->param();
		$where = [];
		if (!empty($param['mobile'])) $where[] = ['mobile', 'like', '%' . $param['mobile'] . '%'];
		if (!empty($param['member_name'])) $where[] = ['member_name', 'like', '%' . $param['member_name'] . '%'];
		$lists = MemberService::getInstance()->getPageLists($where, '*', ['role_id_text']);
		return view('member/index', [
			'lists' => $lists,
			'param' => $param
		]);
	}

	public function form(Request $request)
	{
		$id = $request->param('id');
		$info = [];
		if (!empty($id)) $info = MemberService::getInstance()->findSingle(['id' => $id]);
		return view('member/form', [
			'info'       => $info,
		]);
	}

	public function save(Request $request)
	{
		$param = $request->param();
		try {
			MemberService::getInstance()->saveData($param);
			return JsonResponse::success('操作成功');
		} catch (\Exception $e) {
			return ErrorMsg::errorMsg($e);
		}
	}

	public function del(Request $request)
	{
		$id = $request->param('id');
		if (empty($id)) return JsonResponse::error('非法请求');
		try {
			MemberService::getInstance()->del(['id' => $id]);
			return JsonResponse::success('操作成功');
		} catch (\Exception $e) {
			return ErrorMsg::errorMsg($e);
		}
	}

}