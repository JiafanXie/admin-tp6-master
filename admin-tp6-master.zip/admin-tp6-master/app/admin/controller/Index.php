<?php
declare (strict_types=1);

namespace app\admin\controller;

use app\common\controller\AdminBase;
use app\common\core\traits\Ueditor;
use core\traits\Upload;
use app\Request;
use think\facade\Db;

class Index extends AdminBase
{
	use Ueditor;
	use Upload;

	public function index(Request $request)
	{
		$version = Db::query('SELECT VERSION() AS ver');
		$config  = [
			'url'             => $_SERVER['HTTP_HOST'],
			'document_root'   => $_SERVER['DOCUMENT_ROOT'],
			'server_os'       => PHP_OS,
			'server_port'     => $_SERVER['SERVER_PORT'],
			'server_soft'     => $_SERVER['SERVER_SOFTWARE'],
			'php_version'     => PHP_VERSION,
			'mysql_version'   => $version[0]['ver'],
			'max_upload_size' => ini_get('upload_max_filesize')
		];
		return view('index', [
			'config' => $config,
		]);
	}

	public function uEditor()
	{
		return $this->config();
	}
}