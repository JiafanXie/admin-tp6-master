<?php
declare (strict_types=1);

namespace app\admin\controller;

use app\common\controller\AdminBase;
use core\error\ErrorMsg;
use core\json\JsonResponse;
use app\Request;
use app\service\AdminService;
use app\service\RoleService;

class Admin extends AdminBase
{
	public function index(Request $request)
	{
		$where = [
			['role_id', '>', 0],
		];
		$lists = AdminService::getInstance()->getPageLists($where, '*', ['role_id_text']);
		return view('admin/index', [
			'lists' => $lists
		]);
	}

	public function form(Request $request)
	{
		$id = $request->param('id');
		$info = [];
		if (!empty($id)) $info = AdminService::getInstance()->findSingle(['id' => $id]);
		$role_lists = RoleService::getInstance()->findAll();
		return view('admin/form', [
			'info'       => $info,
			'role_lists' => $role_lists
		]);
	}

	public function save(Request $request)
	{
		$param = $request->param();
		if (!empty($id)) {
			if (empty($param['username']) || empty($param['role_id']))
				return JsonResponse::error('请将信息填写完整');
			if (!empty($param['password'])) {
				$param['salt'] = get_random_str();
				$param['password'] = md5($param['password'] . $param['salt']);
			} else {
				unset($param['password']);
			}
		} else {
			if (empty($param['username']) || empty($param['password']) || empty($param['role_id'])) JsonResponse::error('请将信息填写完整');
			$param['salt'] = get_random_str();
			$param['password'] = md5($param['password'] . $param['salt']);
		}
		try {
			AdminService::getInstance()->saveData($param);
			return JsonResponse::success('操作成功');
		} catch (\Exception $e) {
			return ErrorMsg::errorMsg($e);
		}
	}

	public function del(Request $request)
	{
		$id = $request->param('id');
		if (empty($id)) return JsonResponse::error('非法请求');
		try {
			AdminService::getInstance()->del(['id' => $id]);
			return JsonResponse::success('操作成功');
		} catch (\Exception $e) {
			return ErrorMsg::errorMsg($e);
		}
	}

	/**
	 * 修改密码
	 * @param Request $request
	 * @return \think\response\Json|\think\response\View
	 */
	public function changePassword(Request $request)
	{
		if ($request->isAjax()) {
			$param = $request->param(['password', 'new_password', 'confirm_password']);
			if (empty($param['password']) || empty($param['new_password']) || empty($param['confirm_password'])) $this->error('请将信息填写完整');
			$user_info = AdminService::getInstance()->findSingle(['id' => $this->admin['id']]);
			if (md5($user_info['salt'] . $param['password']) != $user_info['password']) $this->error('当前密码不正确');
			if ($param['new_password'] != $param['confirm_password']) return JsonResponse::error('两次密码不一致');
			$salt = get_random_str();
			$password = md5($param['new_password'] . $salt);
			try {
				$data = [
					'id'       => $user_info->id,
					'password' => $password,
					'salt'     => $salt
				];
				AdminService::getInstance()->saveData($data);
				unset($param, $user_info, $salt, $password);
				return JsonResponse::success('操作成功');
			} catch (\Exception $e) {
				return ErrorMsg::errorMsg($e);
			}
		}
		return view('change_password');
	}
}