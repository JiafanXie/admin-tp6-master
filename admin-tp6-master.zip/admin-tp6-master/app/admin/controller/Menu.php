<?php
declare (strict_types=1);

namespace app\admin\controller;

use app\common\controller\AdminBase;
use core\error\ErrorMsg;
use core\json\JsonResponse;
use app\common\model\Menu as MenuModel;
use app\Request;
use app\service\MenuService;

class Menu extends AdminBase
{
	public function index(Request $request)
	{
		$p_id  = $request->param('p_id', 0);
		$lists = MenuService::getInstance()->findAll(['p_id' => $p_id]);
		return view('index', [
			'lists' => $lists,
			'p_id'  => $p_id
		]);
	}

	public function form(Request $request)
	{
		$id   = $request->param('id');
		$p_id = $request->param('p_id');
		$info = [];
		if (!empty($id)) $info = MenuService::getInstance()->findSingle(['id' => $id]);
		return view('form', [
			'info' => $info,
			'p_id' => $p_id
		]);
	}

	public function save(Request $request)
	{
		$param = $request->param();
		try {
			MenuService::getInstance()->saveData($param);
			return JsonResponse::success('操作成功');
		} catch (\Exception $e) {
			return ErrorMsg::errorMsg($e);
		}
	}

	public function del(Request $request)
	{
		$id = $request->param('id');
		if (empty($id)) return JsonResponse::error('非法请求');
		try {
			$res = MenuModel::getAllSon($id);
			if (empty($res)) {
				MenuService::getInstance()->del(['id' => $id]);
			} else {
				array_push($res, $id);
				MenuModel::destroy($res);
			}
			return JsonResponse::success('操作成功');
		} catch (\Exception $e) {
			return ErrorMsg::errorMsg($e);
		}
	}


}
