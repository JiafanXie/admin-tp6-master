<?php
declare (strict_types=1);

namespace app\admin\controller;

use app\common\controller\AdminBase;

use app\common\model\Log as LogModel;
use app\common\model\Admin;
use app\Request;
use app\service\AdminService;

class Log extends AdminBase
{
	public function index(Request $request)
	{
		$param = $request->get();
		$where = [];
		if (!empty($param['admin_id'])) $where[] = ['admin_id', '=', $param['admin_id']];
		if (!empty($param['start_time'])) $where[] = ['create_time', '>=', strtotime($param['start_time'])];
		if (!empty($param['end_time'])) $where[] = ['create_time', '<=', strtotime($param['end_time'])];
		$lists = LogModel::where($where)->order(['create_time' => 'desc'])->paginate($this->pageSize);
		return view('index', [
			'lists'       => $lists,
			'param'       => $param,
			'admin_lists' => AdminService::getInstance()->findAll([['role_id', '<>', 0]], 'id,username', ['create_time' => 'desc']),
		]);
	}

	public function form(Request $request)
	{
		// TODO: Implement form() method.
	}

	public function save(Request $request)
	{
		// TODO: Implement save() method.
	}

	public function del(Request $request)
	{
		// TODO: Implement del() method.
	}
}