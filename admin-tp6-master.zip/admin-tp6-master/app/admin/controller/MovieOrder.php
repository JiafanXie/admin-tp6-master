<?php
declare(strict_types=1);

namespace app\admin\controller;

use app\common\controller\AdminBase;
use app\Request;
use app\service\MemberService;
use app\service\MovieOrderService;
use core\error\ErrorMsg;
use core\json\JsonResponse;

/**
 * 电影票订单控制器
 * Class MovieOrder
 * @package app\admin\controller
 */
class MovieOrder extends AdminBase
{
	public function index(Request $request)
	{
		$param = $request->param();
		$where = [];
		if (!empty($param['mobile'])) $where[] = ['mobile', 'like', '%' . $param['mobile'] . '%'];
		if (!empty($param['member_name'])) $where[] = ['member_name', 'like', '%' . $param['member_name'] . '%'];
		$lists = MovieOrderService::getInstance()->getPageLists($where, '*', ['role_id_text']);
		return view('movieOrder/index', [
			'lists' => $lists,
			'param' => $param
		]);
	}

	public function del(Request $request)
	{
		$id = $request->param('id');
		if (empty($id)) return JsonResponse::error('非法请求');
		try {
			MovieOrderService::getInstance()->del(['id' => $id]);
			return JsonResponse::success('操作成功');
		} catch (\Exception $e) {
			return ErrorMsg::errorMsg($e);
		}
	}
}