<?php
declare (strict_types=1);

namespace app;

use think\Container;
use think\facade\Db;
use think\Model;

abstract class BaseModel extends Model
{

	/**
	 * 自动时间戳
	 * @var bool
	 */
	protected $autoWriteTimestamp = true;

	/**
	 * 开启事务
	 */
	public static function startTrans()
	{
		Db::startTrans();
	}

	/**
	 * 提交事务
	 */
	public static function commit()
	{
		Db::commit();
	}

	/**
	 * 事务回滚
	 */
	public static function rollback()
	{
		Db::rollback();
	}

	public static function getInstance(): self
	{
		return Container::getInstance()->make(static::class);
	}

}