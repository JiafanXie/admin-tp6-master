<?php
// 应用公共文件

if (!function_exists('is_mobile')) {
	/**
	 * 判断是否为手机访问
	 * @return  boolean
	 */
	function is_mobile()
	{
		static $is_mobile;

		if (isset($is_mobile)) {
			return $is_mobile;
		}

		if (empty($_SERVER['HTTP_USER_AGENT'])) {
			$is_mobile = false;
		} elseif (strpos($_SERVER['HTTP_USER_AGENT'], 'Mobile') !== false || strpos($_SERVER['HTTP_USER_AGENT'], 'Android') !== false || strpos($_SERVER['HTTP_USER_AGENT'], 'Silk/') !== false || strpos($_SERVER['HTTP_USER_AGENT'], 'Kindle') !== false || strpos($_SERVER['HTTP_USER_AGENT'], 'BlackBerry') !== false || strpos($_SERVER['HTTP_USER_AGENT'], 'Opera Mini') !== false || strpos($_SERVER['HTTP_USER_AGENT'], 'Opera Mobi') !== false
		) {
			$is_mobile = true;
		} else {
			$is_mobile = false;
		}

		return $is_mobile;
	}
}
if (!function_exists('positive_integer')) {
	/**
	 * 判断是否为正整数
	 * @param $num
	 * @return false|int
	 */
	function positive_integer($num)
	{
		return preg_match("/^[1-9][0-9]*$/", $num);
	}
}
if (!function_exists('check_mobile_number')) {
	/**
	 * 手机号格式检查
	 * @param string $mobile
	 * @return bool
	 */
	function check_mobile_number($mobile)
	{
		if (!is_numeric($mobile)) {
			return false;
		}
		$reg = '#^13[\d]{9}$|^14[5,7]{1}\d{8}$|^15[^4]{1}\d{8}$|^17[0,6,7,8]{1}\d{8}$|^18[\d]{9}$#';
		return preg_match($reg, $mobile) ? true : false;
	}
}

if (!function_exists('get_random_str')) {
	/**
	 * 生成随机字符串
	 * @return bool|string
	 */
	function get_random_str()
	{
		return substr(str_shuffle(config('app.salt')), mt_rand(0, strlen(config('app.salt')) - 11), 10);
	}
}

if (!function_exists('get_sms_code')) {
	/**
	 * 生成6位数验证码
	 * @return bool|string
	 */
	function get_sms_code()
	{
		$rand_str = str_shuffle('1234567890');
		$rand     = substr($rand_str, 0, 6);
		return $rand;
	}
}

if (!function_exists('delete_dir_file')) {
	/**
	 * 循环删除目录和文件
	 * @param string $dir_name
	 * @return bool
	 */
	function delete_dir_file($dir_name)
	{
		$result = false;
		if (is_dir($dir_name)) {
			if ($handle = opendir($dir_name)) {
				while (false !== ($item = readdir($handle))) {
					if ($item != '.' && $item != '..') {
						if (is_dir($dir_name . DIRECTORY_SEPARATOR . $item)) {
							delete_dir_file($dir_name . DIRECTORY_SEPARATOR . $item);
						} else {
							unlink($dir_name . DIRECTORY_SEPARATOR . $item);
						}
					}
				}
				closedir($handle);
				if (rmdir($dir_name)) {
					$result = true;
				}
			}
		}
		return $result;
	}
}

if (!function_exists('array2tree')) {
	/**
	 * 构建层级（树状）数组
	 * @param array $array 要进行处理的一维数组，经过该函数处理后，该数组自动转为树状数组
	 * @param string $p_id_name 父级ID的字段名
	 * @param string $child_key_name 子元素键名
	 * @return array|bool
	 */
	function array2tree(&$array, $p_id_name = 'p_id', $child_key_name = 'children')
	{
		$counter = array_children_count($array, $p_id_name);
		if (!isset($counter[0]) || $counter[0] == 0) {
			return $array;
		}
		$tree = [];
		while (isset($counter[0]) && $counter[0] > 0) {
			$temp = array_shift($array);
			if (isset($counter[$temp['id']]) && $counter[$temp['id']] > 0) {
				array_push($array, $temp);
			} else {
				if ($temp[$p_id_name] == 0) {
					$tree[] = $temp;
				} else {
					$array = array_child_append($array, $temp[$p_id_name], $temp, $child_key_name);
				}
			}
			$counter = array_children_count($array, $p_id_name);
		}
		return $tree;
	}
}

if (!function_exists('array_children_count')) {
	/**
	 * 子元素计数器
	 * @param array $array
	 * @param int $p_id
	 * @return array
	 */
	function array_children_count($array, $p_id)
	{
		$counter = [];
		foreach ($array as $item) {
			$count = isset($counter[$item[$p_id]]) ? $counter[$item[$p_id]] : 0;
			$count++;
			$counter[$item[$p_id]] = $count;
		}
		return $counter;
	}
}

if (!function_exists('array_child_append')) {
	/**
	 * 把元素插入到对应的父元素$child_key_name字段
	 * @param        $parent
	 * @param        $p_id
	 * @param        $child
	 * @param string $child_key_name 子元素键名
	 * @return mixed
	 */
	function array_child_append($parent, $p_id, $child, $child_key_name)
	{
		foreach ($parent as &$item) {
			if ($item['id'] == $p_id) {
				if (!isset($item[$child_key_name])) $item[$child_key_name] = [];
				$item[$child_key_name][] = $child;
			}
		}
		return $parent;
	}
}

if (!function_exists('array2level')) {
	/**
	 * 数组层级缩进转换
	 * @param array $array 源数组
	 * @param int $p_id
	 * @param int $level
	 * @return array
	 */
	function array2level($array, $p_id = 0, $level = 1)
	{
		static $list = [];
		foreach ($array as $v) {
			if ($v['p_id'] == $p_id) {
				$v['level'] = $level;
				$list[]     = $v;
				array2level($array, $v['id'], $level + 1);
			}
		}
		return $list;
	}
}

if (!function_exists('check_auth')) {
	/**
	 * 检查权限
	 * @param string $path 当前菜单路径
	 * @return bool
	 */
	function check_auth(string $path = '')
	{
		if (empty($path)) return false;
		$admin = session('admin');
		if ($admin['role_id'] == 0) return true;
		$menu = \app\common\model\Menu::findSingle(['name' => $path]);
		if (is_string($menu) || empty($menu)) return false;
		$role = explode(',', \app\common\model\Role::findSingle(['id' => $admin['role_id']])['role']);
		if (!in_array($menu['id'], $role)) return false;
		return true;
	}
}

if (!function_exists('hex_to_str')) {
	/**
	 * 转换二进制
	 * @param $hex
	 * @return string
	 */
	function hex_to_str($hex)
	{
		$str = "";
		for ($i = 0; $i < strlen($hex) - 1; $i += 2)
			$str .= chr(hexdec($hex[$i] . $hex[$i + 1]));
		return $str;
	}
}

if (!function_exists('user')) {
	/**
	 * 获取用户信息
	 * @return bool|object
	 */
	function user()
	{
		$jwt   = new \app\common\core\server\Jwt();
		$token = $jwt->getBearerToken();
		if (!$token) return false;
		$body_info = json_decode(base64_decode(explode('.', $token)[1]), true);
		if ($body_info['exp'] <= time()) return false;
		$res  = $jwt->decryptToken();
		$user = [];
		if (!$res) return false;
		$user = \app\common\model\User::findSingle(['id' => $body_info['id']]);
		return (object)$user;
	}
}

if (!function_exists('str_to_location')) {
	/**
	 * 字符串转经纬度
	 * @param string $str 地址
	 * @return array|bool
	 */
	function str_to_location($str)
	{
		if (empty($str)) return false;
		$url = 'http://api.map.baidu.com/geocoding/v3/?address=' . $str . '&output=json&ak=' . config('third.baidu_map.ak');
		$res = json_decode(curl_request($url));
		if ($res->status == 1) return false;
		$data = [
			'lon' => mb_convert_encoding($res->result->location->lng, 'UTF-8', 'UTF-8,GBK,GB2312,BIG5'),
			'lat' => mb_convert_encoding($res->result->location->lat, 'UTF-8', 'UTF-8,GBK,GB2312,BIG5'),
		];
		return $data;
	}
}

if (!function_exists('curl_request')) {
	/**
	 * curl请求
	 * @param $url
	 * @param string $method
	 * @param null $data
	 * @return mixed
	 */
	function curl_request($url, $method = 'GET', $data = null, $json = false)
	{
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		if ($json) {
			curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json; charset=utf-8']);
		}
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		if ($method == 'POST') {
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
		}
		curl_setopt($ch, CURLOPT_TIMEOUT, 30);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
		$data = curl_exec($ch);
		curl_close($ch);
		return json_decode($data, true);
	}
}
if (!function_exists('get_sign')) {
	/**
	 * 生成签名
	 * @param $info
	 * @return string
	 */
	function get_sign($info)
	{
		$sign = hash_hmac('md5', base64_encode($info), config('app.salt'));
		return $sign;
	}
}

if (!function_exists('compare_sign')) {
	/**
	 * 比对签名
	 * @param string $info 信息
	 * @param string $sign 签名
	 * @return bool
	 */
	function compare_sign($info, $sign)
	{
		$hash   = hash_hmac('md5', base64_encode($info), config('app.salt'));
		$verify = hash_equals($sign, $hash);
		return $verify;
	}
}

if (!function_exists('get_son')) {
	/**
	 * 获取下级
	 * @param $p_id
	 * @return array
	 */
	function get_son($p_id = [])
	{
		$arr = [];
		if (count($p_id) == 0) return $arr;
		try {
			$lists = \app\common\model\User::where('p_id', 'in', $p_id)->field('id')->select()->toArray();
			if (count($lists)) {
				foreach ($lists as $v) {
					$arr[] = $v['id'];
				}
			}
			return $arr;
		} catch (\Exception $e) {
			return $arr;
		}
	}
}

if (!function_exists('m_date')) {

	/**
	 * 转换为多少秒之前
	 * @param $time
	 * @return array
	 */
	function m_date($time)
	{
		$m = intval($time / 60);
		$s = $time % 60;
		return ['m' => $m, 's' => $s];
	}
}

if (!function_exists('period')) {

	/**
	 * 获得当前期号
	 * @return string
	 */
	function period()
	{
		$time = s_time(date('H:i', time()));
		return sprintf('%03d', intval($time / 3));
	}
}

if (!function_exists('open_time')) {

	/**
	 * 获取开奖时间
	 * @param $period
	 * @return float|int
	 */
	function open_time($period)
	{
		return strtotime(date('Y-m-d', time())) + $period * 180 + 180;
	}
}

if (!function_exists('s_time')) {

	/**
	 * 将时间转换为秒
	 * @param $time
	 * @return float|int
	 */
	function s_time($time)
	{
		list($h, $m) = explode(':', $time);
		return $h * 60 + $m;
	}
}

if (!function_exists('dir_exist_file')) {
	/**
	 * 判断某个文件下是否有该文件
	 * @param $path
	 * @param $file
	 * @return bool
	 */
	function dir_exist_file($path, $file)
	{
		if (!is_dir($path)) {
			return false;
		} else {
			$files = scandir($path);
			// 删除  "." 和 ".."
			unset($files[0]);
			unset($files[1]);
			// 判断是否为空
			if (!in_array($file, $files)) return false;
			return true;
		}
	}
}

if (!function_exists('get_client_ip')) {
	/**
	 * 获取客户端ip
	 * @return mixed|string
	 */
	function get_client_ip()
	{
		$ip      = 'unknown';
		$unknown = 'unknown';

		if (isset($_SERVER['HTTP_X_FORWARDED_FOR']) && $_SERVER['HTTP_X_FORWARDED_FOR'] && strcasecmp($_SERVER['HTTP_X_FORWARDED_FOR'], $unknown)) {
			// 使用透明代理、欺骗性代理的情况
			$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];

		} elseif (isset($_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR'] && strcasecmp($_SERVER['REMOTE_ADDR'], $unknown)) {
			// 没有代理、使用普通匿名代理和高匿代理的情况
			$ip = $_SERVER['REMOTE_ADDR'];
		}

		// 处理多层代理的情况
		if (strpos($ip, ',') !== false) {
			// 输出第一个IP
			$ip = reset(explode(',', $ip));
		}

		return $ip;
	}

}

if (!function_exists('process_img')) {
	/**
	 * 将图片拼接上域名
	 * @param $img
	 * @return string
	 */
	function process_img($img): string
	{
		return request()->domain() . $img;
	}
}