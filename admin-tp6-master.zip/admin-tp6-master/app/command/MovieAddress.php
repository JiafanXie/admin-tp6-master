<?php
declare(strict_types=1);

namespace app\command;

use core\third\movie\MovieApi;
use think\console\Command;
use think\console\Input;
use think\console\Output;

/**
 * 影院城市
 * Class MovieCity
 * @package app\command
 */
class MovieAddress extends Command
{
	protected function configure()
	{
		$this->setName('movieAddress');
	}

	protected function execute(Input $input, Output $output)
	{
		MovieApi::getInstance()->addressLists();
		$output->writeln('success');
	}
}