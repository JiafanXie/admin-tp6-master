<?php
declare(strict_types=1);

namespace app\command;

use core\third\movie\MovieApi;
use think\console\Command;
use think\console\Input;
use think\console\Output;

/**
 * 影院城市
 * Class MovieCity
 * @package app\command
 */
class Movie extends Command
{
	protected function configure()
	{
		$this->setName('movie');
	}

	protected function execute(Input $input, Output $output)
	{
		$type = [
			1 => 'hotShowingMovies',
			2 => 'waitShowMovie'
		];
		foreach ($type as $k => $v) {
			MovieApi::getInstance()->movieLists($k, $v);
		}
		$output->writeln('success');
	}
}