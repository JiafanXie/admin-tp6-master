<?php
declare(strict_types=1);

namespace app\command;

use app\service\MovieCityService;
use core\third\movie\MovieApi;
use think\console\Command;
use think\console\Input;
use think\console\Output;
use think\facade\Db;

/**
 * 影院城市
 * Class MovieCity
 * @package app\command
 */
class MovieCinema extends Command
{
	protected function configure()
	{
		$this->setName('movieCinema');
	}

	protected function execute(Input $input, Output $output)
	{
		Db::name('movie_cinema')->delete(true);
		$city_lists = MovieCityService::getInstance()->findAll([], 'city_id', []);
		foreach ($city_lists as $v) {
			$page_total = MovieApi::getInstance()->cinemaLists($v['city_id'], 1)['total_page'];
			swoole_timer_tick(100, function ($timer_id) use ($v, $page_total) {
				$page = 1;
				for ($i = 1; $i <= $page_total; $i++) {
					$data = MovieApi::getInstance()->cinemaLists($v['city_id'], $page);
					$page += 1;
					if ($page > $data['total_page']) swoole_timer_clear($timer_id);
					unset($data['total_page']);
					if (!empty($data)) \app\model\MovieCinema::getInstance()->saveAll($data);
				}
			});
		}
		$output->writeln('success');
	}
}