<?php
declare(strict_types=1);

namespace app\command;

use app\service\MovieCinemaService;
use core\third\movie\MovieApi;
use think\console\Command;
use think\console\Input;
use think\console\Output;

/**
 * 影院城市
 * Class MovieCity
 * @package app\command
 */
class MoviePlan extends Command
{
	protected function configure()
	{
		$this->setName('moviePlan');
	}

	protected function execute(Input $input, Output $output)
	{
		$cinema_list = MovieCinemaService::getInstance()->findAll([], 'cinema_id', []);
		foreach ($cinema_list as $v) {
			swoole_timer_tick(100, function ($timer_id) use ($v) {
				$res = MovieApi::getInstance()->planLists($v->cinema_id);
				if ($res != false) echo $v['cinema_id'] . PHP_EOL;
				swoole_timer_clear($timer_id);
			});
		}
		$output->writeln('success');
	}
}