<?php
/**
 * @File name ServiceBase.php
 * @Date 2020/8/28
 */

namespace app\common\controller;


use think\Container;
use think\Model;

abstract class ServiceBase
{
	/**
	 * @var Model
	 */
	protected $model;

	public function __construct()
	{
		$model = 'app\\model\\' . str_replace('Service', '', explode('\\', static::class)[2]);
		$this->model = new $model;
	}

	/**
	 * @param mixed ...$args
	 * @return static
	 */
	public static function getInstance(...$args): self
	{
		return Container::getInstance()->make(static::class, ...$args);
	}

	/**
	 * 查找单条数据
	 * @param array $where
	 * @param string $field
	 * @param array $order
	 * @return Model
	 */
	public function findSingle(array $where = [], string $field = '*', array $order = ['id' => 'desc'])
	{
		return $this->model->where($where)->order($order)->field($field)->findOrEmpty();
	}

	/**
	 * 查找全部数据
	 * @param array $where
	 * @param string $field
	 * @param array $order
	 * @return mixed
	 * @throws \Exception
	 */
	public function findAll(array $where = [], string $field = '*', array $order = ['id' => 'desc'])
	{
		return $this->model->where($where)->order($order)->field($field)->select();
	}

	/**
	 * 查找部分数据
	 * @param array $where
	 * @param string $field
	 * @param array $order
	 * @param int $page
	 * @param int $page_size
	 * @return string|\think\Collection
	 * @throws \Exception
	 */
	public function findPage(array $where = [], string $field = '*', int $page = 1, array $order = ['id' => 'desc'], int $page_size = 10)
	{
		return $this->model->where($where)->order($order)->field($field)->page($page, $page_size)->select();
	}

	public function getPageLists(array $where, string $field = '*', array $append = [], array $order = ['id' => 'desc'])
	{
		return $this->model->where($where)->order($order)->field($field)->append($append)->paginate(10);
	}

	/**
	 * 新增和更新
	 * @param array $data
	 * @return Model
	 */
	public function saveData(array $data = []): Model
	{
		$id = $data['id'] ?? 0;
		unset($data['id']);
		if ($id > 0) {
			$this->model->findOrEmpty($id)->save($data);
		}
		$this->model->save($data);
		return $this->model;
	}

	/**
	 * 删除
	 * @param array $where
	 * @return bool
	 */
	public function del(array $where = [])
	{
		return $this->model->where($where)->delete();
	}
}