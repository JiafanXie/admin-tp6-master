<?php
declare (strict_types = 1);

namespace app\common\controller;

use app\BaseController;

/**
 * 接口基类
 * Class ApiBase
 * @package app\common\controller
 */
abstract class ApiBase extends BaseController
{

}