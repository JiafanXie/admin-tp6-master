<?php
declare(strict_types=1);

namespace app\service;

use app\common\controller\ServiceBase;

/**
 * 影片服务类
 * Class MovieService
 * @package app\service
 */
class MovieService extends ServiceBase
{

}