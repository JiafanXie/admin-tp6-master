<?php
/**
 * @File name MenuService.php
 * @Date 2020/8/28
 */

namespace app\service;

use app\common\controller\ServiceBase;

/**
 * 菜单服务
 * @ClassName MenuService
 * @Date 2020/8/28
 */
class MenuService extends ServiceBase
{
}