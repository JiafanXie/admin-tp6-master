<?php
declare(strict_types=1);

namespace app\service;

use app\common\controller\ServiceBase;

/**
 * 银行卡信息服务类
 * Class BankInfoService
 * @package app\service
 */
class BankInfoService extends ServiceBase
{

}