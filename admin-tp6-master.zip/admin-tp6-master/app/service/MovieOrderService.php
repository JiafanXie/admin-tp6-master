<?php
declare(strict_types=1);

namespace app\service;

use app\common\controller\ServiceBase;

/**
 * 电影票订单服务类
 * Class MovieOrderService
 * @package app\service
 */
class MovieOrderService extends ServiceBase
{

}