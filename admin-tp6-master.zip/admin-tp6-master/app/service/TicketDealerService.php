<?php
declare(strict_types=1);

namespace app\service;


use app\common\controller\ServiceBase;

class TicketDealerService extends ServiceBase
{

}