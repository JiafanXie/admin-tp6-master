<?php
declare(strict_types=1);
namespace app\service;

use app\common\controller\ServiceBase;

/**
 * 影院城市服务类
 * Class MovieCityService
 * @package app\service
 */
class MovieCityService extends ServiceBase
{

}