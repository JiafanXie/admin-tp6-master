<?php
declare(strict_types=1);

namespace app\service;

use app\common\controller\ServiceBase;

/**
 * 影院服务类
 * Class MovieCinemaService
 * @package app\service
 */
class MovieCinemaService extends ServiceBase
{

}