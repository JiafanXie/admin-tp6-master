<?php
declare(strict_types=1);

namespace app\service;

use app\common\controller\ServiceBase;

/**
 * 客户服务类
 * Class MemberService
 * @package app\service
 */
class MemberService extends ServiceBase
{
}