<?php
declare(strict_types=1);

namespace app\service;

use app\common\controller\ServiceBase;

/**
 * 影院区域服务类
 * Class MovieAddressService
 * @package app\service
 */
class MovieAddressService extends ServiceBase
{

}