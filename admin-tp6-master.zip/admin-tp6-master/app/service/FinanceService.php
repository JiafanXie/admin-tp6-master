<?php
declare(strict_types=1);

namespace app\service;

use app\common\controller\ServiceBase;
use app\model\Finance;
use app\model\Member;
use think\Model;

/**
 * 财务服务类
 * Class FinanceService
 * @package app\service
 */
class FinanceService extends ServiceBase
{
	/**
	 * @var Model
	 */
	protected $model = 'finance';

	public function getPageLists(array $where, string $field = '*', array $append = [], array $order = ['create_time' => 'desc'])
	{
		$mem_where = [];
		if (isset($where['member_name'])) $mem_where = Member::where('member_name', 'like', '%' . $where['member_name'] . '%');
		if (isset($where['mobile'])) $mem_where = Member::where('mobile', 'like', '%' . $where['mobile'] . '%');
		if (isset($where['mobile']) && isset($where['member_name']))
			$mem_where = Member::where('mobile', 'like', '%' . $where['mobile'] . '%')->where('member_name', 'like', '%' . $where['member_name'] . '%');
		return Finance::hasWhere('member', $mem_where)->paginate(10);
	}
}