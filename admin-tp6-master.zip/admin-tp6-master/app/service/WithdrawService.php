<?php
declare(strict_types=1);

namespace app\service;

use app\common\controller\ServiceBase;

/**
 * 提现服务类
 * Class WithdrawService
 * @package app\service
 */
class WithdrawService extends ServiceBase
{

}