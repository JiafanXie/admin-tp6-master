<?php
declare(strict_types=1);

namespace app\service;

use app\common\controller\ServiceBase;

/**
 * 竞价服务类
 * Class BidService
 * @package app\service
 */
class BidService extends ServiceBase
{

}