<?php
declare(strict_types=1);

namespace app\service;

use app\common\controller\ServiceBase;

/**
 * 影院排期服务类
 * Class MoviePlanService
 * @package app\service
 */
class MoviePlanService extends ServiceBase
{

}