<?php
/**
 * @File name AdminService.php
 * @Date 2020/8/28
 */

namespace app\service;


use app\common\controller\ServiceBase;

/**
 * 管理员服务类
 * Class AdminService
 * @package app\service
 */
class AdminService extends ServiceBase
{
}