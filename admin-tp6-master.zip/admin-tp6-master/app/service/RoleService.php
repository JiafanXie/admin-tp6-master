<?php
/**
 * @File name RoleService.php
 * @Date 2020/8/28
 */

namespace app\service;

use app\common\controller\ServiceBase;

/**
 * 角色服务类
 * @ClassName RoleService
 * @Date 2020/8/28
 */
class RoleService extends ServiceBase
{
}