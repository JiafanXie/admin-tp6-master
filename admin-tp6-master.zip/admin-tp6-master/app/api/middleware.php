<?php
// api中间件定义文件
return [
	// 跨域
	\think\middleware\AllowCrossDomain::class,
];
