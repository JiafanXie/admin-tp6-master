<?php
declare(strict_types=1);

namespace app\api\controller;

use app\Request;
use app\service\AdminService;
use core\jwt\Jwt;
use think\exception\HttpResponseException;
use think\response\Json;

/**
 * 票商控制器
 * Class Ticket
 * @package app\api\controller
 */
class Ticket
{
	public function login(Request $request): Json
	{
		$username = $request->post('username');
		$pwd = $request->post('pwd');
		$user_info = AdminService::getInstance()->findSingle(['username' => $username]);
		if ($user_info->isEmpty()) return json(['code' => 1, '账号或密码错误']);
		if ($user_info->status != 1) return json(['code' => 1, '当前账户已被禁用']);
		$pwd = md5($pwd . $user_info->salt);
		if ($pwd != $user_info->pwd) return json(['code' => 1, '账号或密码错误']);;
		unset($user_info->pwd, $user_info->salt);
		$data = [
			'access_token'  => Jwt::getInstance()->createAccessToken($user_info->id),
			'refresh_token' => Jwt::getInstance()->createRefreshToken($user_info->id)
		];
		return json(['code' => 0, 'data' => $data]);
	}

	public function bidLists(): Json
	{

	}
}