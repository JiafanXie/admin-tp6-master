<?php
declare(strict_types=1);

namespace app\api\controller;

use app\BaseController;
use app\BaseModel;
use app\model\MoviePlan;
use app\Request;
use app\service\FinanceService;
use app\service\MemberService;
use app\service\MovieAddressService;
use app\service\MovieCinemaService;
use app\service\MovieCityService;
use app\service\MovieOrderService;
use app\service\MoviePlanService;
use app\service\MovieService;
use core\third\movie\MovieApi;
use think\response\Json;

/**
 * 对外接口
 * Class Movie
 * @package app\admin\controller
 */
class Movie
{
	public function getCityLists(Request $request): Json
	{
		$lists = MovieCityService::getInstance()->findAll([], 'city_id,city_name,letter,hot', ['id' => 'asc']);
		return json(['code' => 0, 'data' => $lists]);
	}

	public function getAddressLists(Request $request): Json
	{
		$city_id = $request->get('city_id', '', 'intval');
		if (empty($city_id)) return json(['code' => -1, 'msg' => '城市id不能为空']);
		$lists = MovieAddressService::getInstance()->findAll(['city_id' => $city_id], 'city_id,address_id,address_name', ['id' => 'asc']);
		return json(['code' => 0, 'data' => $lists]);
	}

	public function getCinemaLists(Request $request): Json
	{
		$city_id = $request->get('city_id', '', 'intval');
		if (empty($city_id)) return json(['code' => -1, 'msg' => '城市id不能为空']);
		$lists = MovieCinemaService::getInstance()->findAll(['city_id' => $city_id], 'cinema_id,cinema_name,address,tel,std_id,movie_address_id,service,lng,lat', ['id' => 'asc']);
		return json(['code' => 0, 'data' => $lists]);
	}

	public function getMovieLists(Request $request): Json
	{
		$type = $request->get('type', 0, 'intval');
		$where = [];
		if (!empty($type)) $where['type'] = $type;
		$field = 'type,movie_id,movie_name,duration,publish_address,publish_date,publish_type,director,cast,summary,language,movie_type,poster,img,grade,like,actors';
		$lists = MovieService::getInstance()->findAll($where, $field, ['id' => 'asc']);
		return json(['code' => 0, 'data' => $lists]);
	}

	public function getMoviePlan(Request $request): Json
	{
		$cinema_id = $request->get('cinema_id', '', 'intval');
		$movie_id = $request->get('movie_id', '', 'intval');
		$start_time = $request->get('start_time', '', 'intval');
		$end_time = $request->get('end_time', '', 'intval');
		if (empty($cinema_id)) return json(['code' => -1, 'msg' => '影院id不能位空']);
		$where[] = ['cinema_id', '=', $cinema_id];
		if (!empty($movie_id)) $where[] = ['movie_id', '=', $movie_id];
		if (!empty($start_time) && empty($end_time)) $where[] = ['start_time', '>=', $start_time];
		if (empty($start_time) && !empty($end_time)) $where[] = ['start_time', '<=', $end_time];
		if (!empty($start_time) && !empty($end_time)) $where[] = ['start_time', 'between', [$start_time, $end_time]];
		$field = '*';
		$lists = MoviePlanService::getInstance()->findAll($where, $field, []);
		return json(['code' => 0, 'data' => $lists]);
	}

	public function getMovieSeat(Request $request): Json
	{
		$plan_id = $request->get('plan_id', '');
		if (empty($plan_id)) return json(['code' => -1, 'msg' => '排期id不能为空']);
		$lists = MovieApi::getInstance()->seatLists($plan_id);
		return json(['code' => 0, 'data' => $lists]);
	}

	public function lockSeat(Request $request): Json
	{
		$seat_id = $request->post('seat_id');
		$plan_id = $request->post('plan_id');
		$seat_name = $request->post('seat_name');
		$seat_num = $request->post('seat_num');
		$mobile = $request->post('mobile');
		if (empty($seat_id)) return json(['code' => -1, 'msg' => '座位id不能为空']);
		if (empty($plan_id)) return json(['code' => -1, 'msg' => '排期id不能为空']);
		if (empty($seat_name)) return json(['code' => -1, 'msg' => '座位名称不能为空']);
		if (empty($seat_num)) return json(['code' => -1, 'msg' => '座位数量不能为空']);
		if (empty($mobile)) return json(['code' => -1, 'msg' => '手机号不能为空']);
		$plan = MoviePlanService::getInstance()->findSingle(['plan_id' => $plan_id], '', []);
		if ($plan->isEmpty()) return json(['code' => -1, '当前排期无数据']);
		$res = MovieApi::getInstance()->lockSeat($seat_id, $mobile);
		$order_data = [
			'mobile'         => $mobile,
			'member_id'      => $request->member->id,
			'order_num'      => 'movie' . $request->member->id . time() . '_' . $res['orderid'],
			'order_amount'   => 0,
			'settled_amount' => $res['price'],
			'movie_id'       => $plan->movie_id,
			'cinema_id'      => $plan->cinema_id,
			'seat_name'      => $seat_name,
			'seat_num'       => $seat_num
		];
		$info = MovieOrderService::getInstance()->saveData($order_data);
		$data = [
			'order_num'    => $info->order_num,
			'order_amount' => $info->order_amount
		];
		return json(['code' => 0, 'data' => $data]);
	}

	public function pay(Request $request): Json
	{
		$order_num = $request->post('order_num');
		$order_amount = $request->post('order_amount');
		if (empty($order_num)) return json(['code' => -1, 'msg' => '订单号不能为空']);
		if (empty($order_amount)) return json(['code' => -1, 'msg' => '订单金额不能为空']);
		$order_info = MovieOrderService::getInstance()->findSingle(['order_num' => $order_num]);
		if ($order_info->isEmpty()) return json(['code' => -1, 'msg' => '订单号不合法']);
		if ($order_amount != $order_info->order_amount) return json(['code' => -1, 'msg' => '订单金额不正确']);
		MovieApi::getInstance()->orderPay($order_info->order_num, $order_info->settled_amount);
		BaseModel::startTrans();
		try {
			MemberService::getInstance()->saveData([
				'id'      => $request->member->id,
				'balance' => $order_info->order_amount
			]);
			FinanceService::getInstance()->saveData([
				'member_id'      => $request->member->id,
				'before_balance' => $request->member->balance,
				'change_balance' => $order_info->order_amount,
				'after_balance'  => $request->member->balance + $order_info->order_amount,
				'remark'         => '出票扣款'
			]);
			BaseModel::commit();
			return json(['code' => 0, 'msg' => '支付成功']);
		} catch (\Exception $e) {
			BaseModel::rollback();
			return json(['code' => -1, 'msg' => '支付失败']);
		}
	}

	public function getTicket(Request $request): Json
	{
		$order_num = $request->get('order_num', '');
		if (empty($order_num)) return json(['code' => -1, 'msg' => '订单号不能为空']);
		$order_info = MovieOrderService::getInstance()->findSingle(['order_num' => $order_num]);
		if ($order_info->isEmpty()) return json(['code' => -1, '订单号不合法']);
		return json(['code' => 0, 'data' => ['ticket' => $order_info->ticket_code]]);
	}
}