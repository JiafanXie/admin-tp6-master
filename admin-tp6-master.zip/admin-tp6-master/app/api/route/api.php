<?php

use think\facade\Route;
use app\middleware\MovieAuth;
use app\middleware\TicketAuth;

Route::group(function () {
	Route::get('movie/getCityLists', 'movie/getCityLists');
	Route::get('movie/getAddressLists', 'movie/getAddressLists');
	Route::get('movie/getCinemaLists', 'movie/getCinemaLists');
	Route::get('movie/getMovieLists', 'movie/getMovieLists');
	Route::get('movie/getMoviePlan', 'movie/getMoviePlan');
	Route::get('movie/getMovieSeat', 'movie/getMovieSeat');
	Route::post('movie/lockSeat', 'movie/lockSeat');
	Route::post('movie/pay', 'movie/pay');
	Route::get('movie/getTicket', 'movie/getTicket');
	Route::post('movie/unlockSeat', 'movie/unlockSeat');
})->middleware(MovieAuth::class);

Route::group(function () {
	Route::post('ticket/login', 'ticket/login');
})->middleware(TicketAuth::class);