<?php
declare (strict_types=1);

namespace app\middleware;

use app\common\controller\IndexBase;

class IndexAuth extends IndexBase
{
	protected $except = [
		'login/login',
		'login/register',
		'login/forgetpwd',
		'login/sendcode',
		'index/index',
		'goodlists/index',
		'goodlists/detail',
		'quiz/create',
	];

	/**
	 * @param $request
	 * @param \Closure $next
	 * @return mixed|\think\response\Redirect
	 */
	public function handle($request, \Closure $next)
	{
		$user = session('user');
		$path = strtolower(ltrim(explode('.', $request->pathinfo())[0], '/'));
		if (!in_array($path, $this->except) && empty($user) && $path != '') {
			if ($request->isAjax()) $this->error('please log in first', -2);
			return redirect((string)url('Login/login'));
		}
		return $next($request);
	}
}
