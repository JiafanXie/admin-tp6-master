<?php
declare (strict_types=1);

namespace app\middleware;

use app\common\controller\AdminBase;
use app\common\model\Menu;
use app\common\model\Log as LogModel;

class Log extends AdminBase
{

	protected $except = [
		'admin/login/login',
		'admin/login/captcha',
		'admin/index/index',
	];

	public function handle($request, \Closure $next)
	{
		$response = $next($request);
		$path = ltrim($request->root() . '/' . explode('.', $request->pathinfo())[0], '/');;
		$admin = session('admin');
		if (!in_array($path, $this->except) && $admin['id'] != 1) {
			$data = [
				'admin_id' => $admin['id'],
				'admin_name' => $admin['username'],
				'data'       => serialize($request->post()),
				'path'       => $path,
				'ip'         => get_client_ip(),
				'desc'       => Menu::findSingle(['name' => $path])['title']
			];
			LogModel::saveData($data);
		}
		return $response;
	}
}
