<?php
declare (strict_types=1);

namespace app\middleware;

use app\service\MemberService;

class MovieAuth
{

	/**
	 * @param $request
	 * @param \Closure $next
	 * @return mixed
	 */
	public function handle($request, \Closure $next)
	{
		$param = $request->param();
		if (!isset($param['vendor'])) return json(['code' => -1, 'msg' => '通道号不能为空']);
		if (!isset($param['time'])) return json(['code' => -1, 'msg' => '时间戳不能为空']);
		if (!isset($param['sign'])) return json(['code' => -1, 'msg' => '签名不能为空']);
		if (!isset($param['rand_str'])) return json(['code' => -1, 'msg' => '随机字符串不能为空']);
		if (strlen($param['rand_str']) > 32) return json(['code' => -1, 'msg' => '随机字符串长度不得超过32位']);
//		if (MovieConfig::getInstance()->checkSign($param) == false) return json(['code' => -2, 'msg' => '签名错误']);
		$request->member = MemberService::getInstance()->findSingle(['vendor' => $param['vendor']]);
		unset($param['vendor'], $param['time'], $param['sign'], $param['rand_str']);
		return $next($request);
	}
}
