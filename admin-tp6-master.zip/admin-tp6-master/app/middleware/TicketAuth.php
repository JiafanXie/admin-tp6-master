<?php
declare(strict_types=1);

namespace app\middleware;


use core\jwt\Jwt;

class TicketAuth
{
	protected $expire = [
		'ticket/login'
	];

	public function handle($request, \Closure $next)
	{
		$path_info = request()->pathinfo();
		$token = Jwt::getInstance()->getBearerToken();
		$expire_token = Jwt::getInstance()->expireToken();
		if (Jwt::getInstance()->validateToken() == false) {
			if (!in_array($path_info, $this->expire) && (in_array($token, $expire_token)))
				return json(['code' => 2, 'msg' => '请先登录']);
		}
		return $next($request);
	}
}