<?php
declare(strict_types=1);

namespace app\model;

use app\BaseModel;
use think\model\Relation;

/**
 * 财务模型
 * Class Finance
 * @package app\common\model
 */
class Finance extends BaseModel
{
	public function member(): Relation
	{
		return $this->belongsTo(Member::class, 'member_id');
	}

	public function getMemberIdTextAttr():string
	{
		return $this->member->member_name;
	}

	public function getMemberMobileTextAttr():string
	{
		return $this->member->mobile;
	}
}