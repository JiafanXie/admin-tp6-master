<?php
declare(strict_types=1);

namespace app\model;

use app\BaseModel;

/**
 * 竞价模型
 * Class Bid
 * @package app\model
 */
class Bid extends BaseModel
{

}