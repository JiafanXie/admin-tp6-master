<?php
declare (strict_types=1);

namespace app\model;

use app\BaseModel;

/**
 * 角色模型
 * Class Role
 * @package app\common\model
 */
class Role extends BaseModel
{

}