<?php
declare(strict_types=1);

namespace app\model;

use app\BaseModel;
use think\model\Relation;

/**
 * 电影票订单模型
 * Class MovieOrder
 * @package app\common\model
 */
class MovieOrder extends BaseModel
{
	public function movie():Relation
	{
		return $this->belongsTo(Movie::class, 'movie_id');
	}

	public function cinema():Relation
	{
		return $this->belongsTo(MovieCinema::class, 'cinema_id');
	}
}