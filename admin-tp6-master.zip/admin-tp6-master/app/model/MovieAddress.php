<?php
declare(strict_types=1);

namespace app\model;

use app\BaseModel;

/**
 * 影院地区模型
 * Class MovieAddress
 * @package app\model
 */
class MovieAddress extends BaseModel
{

}