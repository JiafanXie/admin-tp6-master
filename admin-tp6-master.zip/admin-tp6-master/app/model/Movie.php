<?php
declare(strict_types=1);

namespace app\model;

use app\BaseModel;

/**
 * 影片模型
 * Class Movie
 * @package app\common\model
 */
class Movie extends BaseModel
{
	public function getImgAttr($v):array
	{
		return unserialize($v);
	}

	public function getActorsAttr($v):array
	{
		return unserialize($v);
	}
}