<?php
declare(strict_types=1);

namespace app\model;

use app\BaseModel;

/**
 * 影院城市列表
 * Class MovieCity
 * @package app\model
 */
class MovieCity extends BaseModel
{

}