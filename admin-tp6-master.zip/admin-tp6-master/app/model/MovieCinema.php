<?php
declare(strict_types=1);

namespace app\model;

use app\BaseModel;

/**
 * 影院模型
 * Class MovieCinema
 * @package app\common\model
 */
class MovieCinema extends BaseModel
{

	public function getServiceAttr($v):array
	{
		return unserialize($v);
	}
}