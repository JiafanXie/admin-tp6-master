<?php
declare(strict_types=1);

namespace app\model;

use app\BaseModel;

/**
 * 影院排期模型
 * Class MoviePlan
 * @package app\model
 */
class MoviePlan extends BaseModel
{

}