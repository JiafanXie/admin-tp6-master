<?php
declare(strict_types=1);

namespace app\model;

use app\BaseModel;

/**
 * 票商模型
 * Class TicketDealer
 * @package app\model
 */
class TicketDealer extends BaseModel
{

}