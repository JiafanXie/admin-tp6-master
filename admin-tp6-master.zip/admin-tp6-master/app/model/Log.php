<?php
declare (strict_types=1);

namespace app\model;

use app\BaseModel;

/**
 * 日志模型
 * Class Log
 * @package app\common\model
 */
class Log extends BaseModel
{
	public function getDataAttr($v)
	{
		return unserialize($v) ? implode(',', unserialize($v)) : '';
	}
}