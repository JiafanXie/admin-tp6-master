<?php
declare(strict_types=1);

namespace app\model;

use app\BaseModel;

/**
 * 提现模型
 * Class Withdraw
 * @package app\model
 */
class Withdraw extends BaseModel
{

}