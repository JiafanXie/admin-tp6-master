<?php
declare(strict_types=1);

namespace app\model;

use app\BaseModel;

/**
 * 银行卡信息模型
 * Class BankInfo
 * @package app\model
 */
class BankInfo extends BaseModel
{

}