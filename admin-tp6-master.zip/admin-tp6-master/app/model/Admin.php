<?php
declare (strict_types = 1);

namespace app\model;

use app\BaseModel;

/**
 * 管理员模型
 * Class Admin
 * @package app\common\model
 */
class Admin extends BaseModel
{
	public function role()
	{
		return $this->belongsTo(Role::class);
	}

	public function getRoleIdTextAttr():string
	{
		return $this->role->role_name;
	}
}