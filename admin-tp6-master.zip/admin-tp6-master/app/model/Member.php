<?php
declare(strict_types=1);

namespace app\model;

use app\BaseModel;

/**
 * 客户模型
 * Class Member
 * @package app\common\model
 */
class Member extends BaseModel
{

}