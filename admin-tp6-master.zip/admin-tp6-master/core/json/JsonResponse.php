<?php

namespace core\json;

use think\response\Json;

class JsonResponse
{
	/**
	 * 返回错误数据
	 * @param string $msg
	 * @param int $code
	 * @param int $http_code
	 * @return Json
	 */
	public static function error(string $msg, int $code = -1, int $http_code = 200)
	{
		return json(['code' => $code, 'msg' => $msg], $http_code);
	}

	/**
	 * 返回成功数据
	 * @param $data
	 * @param int $code
	 * @param int $http_code
	 * @return Json
	 */
	public static function success($data, int $code = 1, int $http_code = 200)
	{
		if (is_string($data))
			return json(['code' => $code, 'msg' => $data, 'data' => []], $http_code);
		else
			return json(['code' => $code, 'msg' => '', 'data' => $data], $http_code);
	}
}