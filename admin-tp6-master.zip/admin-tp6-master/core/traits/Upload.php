<?php

namespace core\traits;

use core\json\JsonResponse;
use app\Request;
use think\facade\Filesystem;

trait Upload
{
	public function uploadImg(Request $request)
	{
		// 获取表单上传文件 例如上传了001.jpg
		$file = $request->file('file');
		// 上传到本地服务器
		$save_name = Filesystem::disk('public')->putFile('upload', $file);
		$path = '/storage/' . $save_name;
		return JsonResponse::success(['path' => $path], '上传成功');
	}
}