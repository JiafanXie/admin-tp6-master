<?php


namespace core\error;

use core\json\JsonResponse;
use think\Container;
use think\Exception;

/**
 * 返回错误信息类
 * Class ErrorMsg
 * @package app\common\core\error
 */
class ErrorMsg
{

	public static function errorMsg(\Exception $e)
	{
		if (env('app_debug')) return JsonResponse::error($e->getMessage());
		return JsonResponse::error('系统异常');
	}
}