<?php
declare(strict_types=1);

namespace core\third\movie;

use app\service\MemberService;
use think\Container;

/**
 * 第三方配置类
 * Class MovieConfig
 * @package core\movie
 */
class MovieConfig
{

	/**
	 * 请求地址
	 * @var string
	 */
//	protected $url = 'http://film-api.trtec.net/partner/ticket/';
	protected $url = 'http://dev.imanm.com/manman/index.php/open/partner/';

	/**
	 * 通道号
	 * @var string
	 */
//	protected $vendor = '00003';
	protected $vendor = '12341398';

	/**
	 * 接口凭证
	 * @var string
	 */
//	protected $apiKey = '85773cc55de29a30d5275874b5164f06';
	protected $apiKey = 'ad3d596cd23935d9d93a20ecab784e82';

	/**
	 * 获取请求地址
	 * @return string
	 */
	public function getUrl(): string
	{
		return $this->url;
	}

	/**
	 * 获取通道号
	 * @return string
	 */
	public function getVendor(): string
	{
		return $this->vendor;
	}

	/**
	 * 获取接口凭证
	 * @return string
	 */
	public function getApiKey(): string
	{
		return $this->apiKey;
	}

	/**
	 * 制作签名
	 * @param array $data
	 * @return string
	 */
	public function makeSign(array $data): string
	{
		ksort($data);
		$sign = '';
		foreach ($data as $k => $v) {
			if ($k == 'sign') continue;
			if (is_array($v) || is_object($v))
				$sign .= $k;
			else
				is_null($v) ? $sign .= '' : $sign .= $k . $v;
		}
		return md5($sign . $this->apiKey);
	}


	/**
	 * 检验签名
	 * @param array $data
	 * @return bool
	 */
	public function checkSign(array $data): bool
	{
		krsort($data);
		$api_key = MemberService::getInstance()->findSingle(['vendor' => $data['vendor']], 'api_key')->api_key;
		$sign = '';
		foreach ($data as $k => $v) {
			if ($k == 'sign') continue;
			if (is_array($v) || is_object($v))
				$sign .= $k;
			else
				is_null($v) ? $sign .= '' : $sign .= $k . $v;
		}
		$sign = md5($sign . $api_key);
		if ($sign != $data['sign']) return false;
		return true;
	}

	/**
	 * 拼接请求地址
	 * @param $url
	 * @return string
	 */
	public function spliceUrl($url): string
	{
		return $this->url . $url;
	}

	/**
	 * 获取请求参数
	 * @param array $data
	 * @return array
	 */
	public function getData(array $data = []): array
	{
		$data = array_merge($data, [
			'channelId' => $this->vendor,
		]);
		$data['sign'] = $this->makeSign($data);
		return $data;
	}

	/**
	 * @param string $url
	 * @param array $param
	 * @return array
	 */
	public function requestApi(string $url, array $param)
	{
		return curl_request($this->spliceUrl($url), 'POST', json_encode($param), true, true);
	}

	public static function getInstance(): self
	{
		return Container::getInstance()->make(static::class);
	}
}