<?php
declare(strict_types=1);

namespace core\third\movie;

use app\model\Movie;
use app\model\MovieAddress;
use app\model\MovieCity;
use app\model\MoviePlan;
use app\service\MovieOrderService;
use core\json\JsonResponse;
use think\exception\HttpResponseException;
use think\facade\Db;

/**
 * 电影票统一服务类
 * Class Movie
 * @package core\movie
 */
class MovieApi extends MovieConfig
{
	/**
	 * 城市列表
	 * @throws \Exception
	 */
	public function cityLists()
	{
		$res = $this->requestApi('queryCitys', $this->getData());
		if ($res['code'] != 0) throw new HttpResponseException(JsonResponse::error('请求城市列表报错'));
		Db::name('movie_city')->delete(true);
		$data = [];
		foreach ($res['result']['cityList'] as $k => &$v) {
			$data[$k] = [
				'city_name' => $v['cityName'],
				'city_id'   => $v['cityId'],
				'letter'    => $v['firstletter'],
				'hot'       => $v['ishot'] ? 1 : 2
			];
		}
		unset($v, $res);
		MovieCity::getInstance()->saveAll($data);
	}

	/**
	 * 获取区域列表
	 * @throws \Exception
	 */
	public function addressLists()
	{
		set_time_limit(0);
		$city = MovieCity::getInstance()->field('city_id')->select();
		if ($city->isEmpty()) throw new HttpResponseException(JsonResponse::error('当前无城市列表'));
		Db::name('movie_address')->delete(true);
		foreach ($city as $v) {
			$res = $this->requestApi('queryCityRegion', $this->getData(['cityid' => $v->city_id]));
			if ($res['code'] != 0) throw new HttpResponseException(JsonResponse::error('区域列表报错'));
			$data = [];
			if (!empty($res['result']['regionList'])) {
				foreach ($res['result']['regionList'] as $val) {
					$data[] = [
						'city_id'      => $v['city_id'],
						'address_id'   => $val['regionid'],
						'address_name' => $val['regionname']
					];
				}
				unset($res);
				MovieAddress::getInstance()->replace()->saveAll($data);
			}
		}
	}

	/**
	 * 影院列表
	 * @param $city_id
	 * @param int $page
	 * @return array
	 * @throws \Exception
	 */
	public function cinemaLists($city_id, $page = 1): array
	{
		$param = [
			'cityId' => $city_id,
			'page'   => $page,
			'step'   => 10
		];
		$res = $this->requestApi('queryCinemas', $this->getData($param));
		if ($res['code'] != 0) throw new HttpResponseException(JsonResponse::json(500, $res));
		$data = [];
		if (!empty($res['result']['cinemasList'])) {
			foreach ($res['result']['cinemasList'] as $v) {
				$data[] = [
					'city_id'          => $city_id,
					'cinema_id'        => $v['cinemaId'],
					'cinema_name'      => $v['cinemaName'],
					'address'          => $v['cinemaAddr'],
					'tel'              => $v['tel'],
					'std_id'           => $v['std_cinema_id'],
					'movie_address_id' => $v['regionid'],
					'service'          => serialize((array)$v['cinemaService']),
					'lng'              => $v['longitude'],
					'lat'              => $v['latitude'],
				];
			}
		}
		$data['total_page'] = $res['result']['pageTotal'];
		unset($res, $v);
		return $data;
	}

	/**
	 * 影片列表
	 * @param $type
	 * @param $url
	 * @throws \Exception
	 */
	public function movieLists($type, $url)
	{
		$res = $this->requestApi($url, $this->getData());
		if ($res['code'] != 0) throw new HttpResponseException(JsonResponse::json(500, $res));
		$data = [];
		$res = $type == 1 ? $res['result']['filmList'] : $res['result']['movielist'];
		foreach ($res as $v) {
			$data[] = [
				'type'            => $type,
				'movie_id'        => $v['filmId'],
				'movie_name'      => $v['name'],
				'duration'        => $v['duration'],
				'publish_address' => $v['moviearea'] ?? '',
				'publish_date'    => $v['publishDate'],
				'publish_type'    => $v['versionTypes'],
				'director'        => $v['director'],
				'cast'            => $v['cast'],
				'summary'         => $v['intro'],
				'language'        => $v['language'],
				'movie_type'      => $v['filmTypes'],
				'poster'          => $v['pic'],
				'img'             => serialize($v['imgs']),
				'grade'           => $v['grade'],
				'like'            => $v['like'],
				'actors'          => serialize($v['actors']),
			];
		}
		unset($v, $res);
		Movie::getInstance()->saveAll($data);
	}

	/**
	 * 获取影院排期列表
	 * @param $cinema_id
	 * @throws \Exception
	 */
	public function planLists($cinema_id)
	{
		$param = ['cinemaId' => $cinema_id];
		$res = $this->requestApi('queryShows', $this->getData($param));
		if (isset($res['code']) == false) throw new HttpResponseException(JsonResponse::error('获取排期失败'));
		if ($res['code'] != 0) throw new HttpResponseException(JsonResponse::error('获取排期失败'));
		$data = [];
		foreach ($res['result']['showList'] as $v) {
			$data[] = [
				'cinema_id'      => $v['cinemaId'],
				'hall_name'      => $v['hallName'],
				'movie_id'       => $v['filmId'],
				'plan_id'        => $v['showId'],
				'start_time'     => strtotime($v['showTime']),
				'stop_sell_time' => strtotime($v['stopSellTime']),
				'settle_price'   => $v['settlePrice'],
				'market_price'   => $v['netPrice'],
				'plan_type'      => $v['planType'],
			];
		}
		unset($v);
		if (empty($data)) return false;
		return MoviePlan::getInstance()->saveAll($data);
	}

	/**
	 * 获取排期座位信息
	 * @param $plan_id
	 * @return array
	 * @throws \Exception
	 */
	public function seatLists($plan_id): array
	{
		$param = ['showId' => $plan_id];
		$res = $this->requestApi('queryShowSeats', $this->getData($param));
		if ($res['code'] != 0) throw new HttpResponseException(JsonResponse::error('获取座位信息失败，请联系管理员处理'));
		$data = [];
		foreach ($res['result']['seats'] as $v) {
			// 1 => 可售， 2 => 不可售
			$v['status'] == 'N' ? $status = 1 : $status = 2;
			// 1 => 非情侣座位，2 => 情侣座位左， 3 => 情侣座位右
			$love_flag = 1;
			if ($v['lovestatus'] == 0) $love_flag = 1;
			if ($v['lovestatus'] == 1) $love_flag = 2;
			if ($v['lovestatus'] == 2) $love_flag = 3;
			$data[] = [
				'column_no' => $v['columnNo'],
				'row_no'    => $v['rowNo'],
				'seat_name' => $v['seatNo'],
				'status'    => $status,
				'love_flag' => $love_flag,
				'seat_id'   => $v['seatId'],
			];
		}
		unset($v);
		$data['max_buy'] = $res['result']['restrictions'];
		unset($res);
		return $data;
	}

	/**
	 * 锁座
	 * @param $seat_id string 座位id
	 * @param $mobile string 手机号
	 * @return array
	 * @throws HttpResponseException
	 */
	public function lockSeat($seat_id, $mobile): array
	{
		$param = [
			'seatId' => $seat_id,
			'phone'  => $mobile
		];
		$res = $this->requestApi('submitOrder', $this->getData($param));
		if ($res['code'] != 0) {
			if ($res['code'] == 1) throw new HttpResponseException(JsonResponse::error($res['message']));
			throw new HttpResponseException(JsonResponse::error('提交订单失败，请联系管理员'));
		}
		return $res['result'];
	}

	/**
	 * 支付
	 * @param string $order_num
	 * @param string $sum_price
	 * @return bool
	 */
	public function orderPay(string $order_num, string $sum_price): bool
	{
		$third_order_id = explode('_', $order_num)[1];
		$param = [
			'orderId'   => $third_order_id,
			'total'     => $sum_price,
			'payStatus' => 1
		];
		$res = $this->requestApi('confirmOrder', $this->getData($param));
		if ($res['code'] != 0 || $res['result']['payResult'] != 1) {
			if ($res['code'] == 1) throw new HttpResponseException(JsonResponse::error($res['message']));
			throw new HttpResponseException(JsonResponse::error('支付失败，请联系管理员处理'));
		}
		return true;
	}

	/**
	 * 查询出票信息
	 * @param string $order_num
	 * @return bool
	 */
	public function findOrder(string $order_num): bool
	{
		$param = ['orderId' => explode('_', $order_num)[1]];
		$res = $this->requestApi('queryOrder', $this->getData($param));
		if ($res['code'] != 0 || $res['data']['status'] != 2 || $res['data']['status'] != 4) {
			if ($res['code'] == 1) throw new HttpResponseException(JsonResponse::error($res['message']));
			throw new HttpResponseException(JsonResponse::error('出票失败，请联系管理员'));
		}
		$update_param['where'] = ['order_num' => $order_num];
		if (count($res['data']['ticketList']) == 1)
			$ticket_code = $res['data']['ticketList']['code']['text'] . ':' . $res['data']['ticketList']['code']['value'];
		else {
			$ticket_code = '';
			foreach ($res['data']['ticketList']['code'] as $v) {
				$ticket_code .= $v['text'] . $v['value'];
			}
		}
		$update_param['data'] = [
			'ticket_code' => $ticket_code,
			'machine'     => $res['data']['ticketList']['machineInfo'],
			'status'      => MovieOrderService::getInstance()->getTicket()
		];
		return MovieOrderService::getInstance()->updateData($update_param);
	}

	/**
	 * 解锁座位
	 * @param string $order_num
	 * @return bool
	 */
	public function unlockSeat(string $order_num): bool
	{
		$param = ['orderId' => explode('_', $order_num)[1]];
		$res = $this->requestApi('releaseOrder', $this->getData($param));
		if ($res['code'] != 0 || $res['releaseResult'] == 0) {
			if ($res['code'] == 1) throw new HttpResponseException(JsonResponse::error($res['message']));
			throw new HttpResponseException(JsonResponse::error('解锁失败'));
		}
		return true;
	}
}