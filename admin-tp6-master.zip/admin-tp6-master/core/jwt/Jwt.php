<?php
declare(strict_types=1);

namespace core\jwt;

use think\App;
use Firebase\JWT\JWT as JwtService;

/**
 * Token
 * Class Jwt
 * @package core\service\jwt
 */
class Jwt
{
	/**
	 * jwt密钥
	 * @var string
	 */
	protected $key;

	/**
	 * 签发时间
	 * @var int
	 */
	protected $iat;

	/**
	 * 生效时间
	 * @var int
	 */
	protected $nbf;

	/**
	 * access_token过期时间
	 * @var int
	 */
	protected $accessTokenExp;

	/**
	 * refresh_token过期时间
	 * @var int
	 */
	protected $refreshTokenExp;

	/**
	 * 基础赋值
	 * Jwt constructor.
	 */
	public function __construct()
	{
		$this->key = config('jwt.key');
		$this->iat = config('jwt.iat');
		$this->nbf = config('jwt.nbf');
		$this->accessTokenExp = config('jwt.access_token_exp');
		$this->refreshTokenExp = config('jwt.refresh_token_exp');
	}

	/**
	 * 创建token
	 * @param int $user_id 用户ID
	 * @return string
	 */
	public function createAccessToken($user_id): string
	{
		$payload = [
			"user_id" => $user_id,
			"iss"     => "谨秉科技",//签发组织
			"iat"     => $this->iat,
			"nbf"     => $this->nbf,
			"exp"     => $this->accessTokenExp
		];
		return JwtService::encode($payload, md5($this->key));
	}

	/**
	 * 生成refresh_token
	 * @param int $user_id
	 * @return string
	 */
	public function createRefreshToken($user_id): string
	{
		$payload = [
			"user_id" => $user_id,
			"iss"     => "谨秉科技",//签发组织
			"iat"     => $this->iat,
			"nbf"     => $this->nbf,
			"exp"     => $this->refreshTokenExp
		];
		return JwtService::encode($payload, md5($this->key), 'HS512');
	}

	/**
	 * 获取客户端token
	 * @return bool|false|string
	 */
	public function getBearerToken()
	{
		$token = '';
		if (!isset($_SERVER['HTTP_' . strtoupper('Authorization')])) return $token; // 头部不存在 Authorization
		$token = $_SERVER['HTTP_' . strtoupper('Authorization')];
		if (substr($token, 0, strlen('Bearer ')) !== 'Bearer ') return $token; // token 不存在
		// Bearer 字符串和空格之后的字符串，是从7开始的
		return substr($token, 7);
	}

	/**
	 * 验证token
	 * @return bool
	 */
	public function validateToken(): bool
	{
		$token = $this->getBearerToken();
		if (empty($token)) return false;
		if (empty($this->decryptToken($token))) return false;
		return true;
	}

	/**
	 * 解密token
	 * @param string $token
	 * @param array $type
	 * @return array
	 */
	public function decryptToken(string $token, array $type = ['HS256']): array
	{
		if (empty($token)) return [];
		return (array)JwtService::decode($token, md5($this->key), $type);
	}

	/**
	 * 所有过期的token
	 * @return array
	 */
	public function expireToken(): array
	{
		return cache('expire_token') ?: [];
	}

	/**
	 * 将token设置为过期
	 * @param string $token
	 * @return bool
	 */
	public function insertExpireToken(string $token): bool
	{
		$expire_token = $this->expireToken();
		array_push($expire_token, $token);
		return cache('expire_token', $expire_token);
	}

	/**
	 * 单例调用
	 * @param mixed ...$args
	 * @return static
	 */
	public static function getInstance(...$args): self
	{
		return App::getInstance()->make(static::class, $args);
	}
}